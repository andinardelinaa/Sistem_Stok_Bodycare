<?php
//Menggabungkan dengan file koneksi yang telah kita buat
include 'koneksi_barang.php';
 
// Load library phpspreadsheet
require('vendor/vendor/autoload.php');
 
use PhpOffice\PhpSpreadsheet\Helper\Sample;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
// End load library phpspreadsheet
 
$spreadsheet = new Spreadsheet();
 
// Set document properties
$spreadsheet->getProperties()->setCreator('Andin Ardelina')
->setLastModifiedBy(' Andin Ardelina')
->setTitle('BodyCare')
->setSubject('BodyCare')
->setDescription('BodyCare')
->setKeywords('BodyCare')
->setCategory('BodyCare');
 
$spreadsheet->getActiveSheet()->mergeCells('A1:H1');
$spreadsheet->setActiveSheetIndex(0)
->setCellValue('A3', 'No')
->setCellValue('B3', 'Jenis Barang')
->setCellValue('C3', 'Nama Barang')
->setCellValue('D3', 'No Barang')
->setCellValue('E3', 'Tanggal Pembelian')
->setCellValue('F3', 'Harga Barang')
->setCellValue('G3', 'Jumlah Barang')
->setCellValue('H3', 'Total Bayar ');

include ('koneksi_barang.php');
$query = mysqli_query($connection,"SELECT * FROM bt_bodycare");
$i = 4;
$no = 1;
while($row = mysqli_fetch_array($query)){
  $spreadsheet->setActiveSheetIndex(0)
	->setCellValue('A'.$i, $no)
	->setCellValue('B'.$i, $row['jenis_barang'])
	->setCellValue('C'.$i, $row['nama_barang'])
	->setCellValue('D'.$i, $row['nomor_barang'])
	->setCellValue('E'.$i, $row['tanggal'])
  ->setCellValue('F'.$i, $row['harga_barang'])
  ->setCellValue('G'.$i, $row['jumlah_barang'])
  ->setCellValue('H'.$i, $row['total_bayar']);
	$i++; 
  $no++;

}
$spreadsheet->getActiveSheet()->setTitle('BodyCare '.date('d-m-Y H'));

$spreadsheet->setActiveSheetIndex(0);

// Redirect output to a client’s web browser (Xlsx)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Report Excel.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');
 
// If you're serving to IE over SSL, then the following may be needed
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header('Pragma: public'); // HTTP/1.0


$writer = IOFactory::createWriter($spreadsheet, 'xlsx');
$writer->save('php://output');

?>



